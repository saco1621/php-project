<?php
echo 'Speech is silver.';
?>	